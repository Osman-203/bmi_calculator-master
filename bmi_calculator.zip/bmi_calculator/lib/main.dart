import 'package:flutter/material.dart';
import 'age_card.dart';
import 'gender_selection.dart';
import 'weight_slider.dart';
import 'ruler_slider.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

void main() => runApp(BMICalculator());

class BMICalculator extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MainPage(),
      theme: ThemeData.light(),
    );
  }
}

class MainPage extends StatefulWidget {
  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('BMI CALCULATOR'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Column(
                  children: [
                    CircularButton(
                      onPress: () {
                        setState(() {});
                      },
                      icon: Icon(FontAwesomeIcons.mars),
                    ),
                    SizedBox(
                      height: 10.0,
                    ),
                    Text('Male'),
                  ],
                ),
                SizedBox(width: 15.0),
                Column(
                  children: [
                    CircularButton(
                      onPress: () {},
                      icon: Icon(FontAwesomeIcons.venus),
                    ),
                    SizedBox(
                      height: 10.0,
                    ),
                    Text('Female'),
                  ],
                )
              ],
            ),
            SizedBox(
              height: 10.0,
            ),
            Row(
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    // Image Container
                    Container(
                      child: WeightSlider(),
                    ),
                    SizedBox(
                      width: 50.0,
                      height: 50.0,
                    ),
                    Container(height: 100, width: 250, child: AgeCard()),
                  ],
                ),
                RulerSlider(),
              ],
            ),
            Container(
              width: double.infinity,
              height: 70,
              color: Colors.blueAccent,
            )
          ],
        ),
      ),
    );
  }
}
