import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:ruler_picker/ruler_picker.dart';

class RulerSlider extends StatefulWidget {
  @override
  _RulerSliderState createState() => _RulerSliderState();
}

class _RulerSliderState extends State<RulerSlider> {
  RulerPickerController rulerPickerController;
  TextEditingController textEditingController;
  num showValue = 0;

  @override
  void initState() {
    super.initState();
    rulerPickerController = RulerPickerController(value: 0);
    textEditingController = TextEditingController(text: '0');
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        RotatedBox(
          quarterTurns: 1,
          child: RulerPicker(
            controller: rulerPickerController,
            onValueChange: (value) {
              setState(() {
                textEditingController.text = value.toString();
              });
            },
            width: 400,
            height: 130,
          ),
        ),
        Container(
          margin: EdgeInsets.only(top: 20),
          width: 60,
          child: CupertinoTextField(
            controller: textEditingController,
            onChanged: (value) {
              showValue = int.parse(value);
            },
            onEditingComplete: () {
              rulerPickerController.value = showValue;
            },
          ),
        ),
      ],
    );
  }
}

// a text field to sync the value of the ruler picker
//            Container(
//              margin: EdgeInsets.only(top: 20),
//              width: 30,
//              child: CupertinoTextField(
//                controller: _textEditingController,
//                onChanged: (value) {
//                  showValue = int.parse(value);
//                },
//                onEditingComplete: () {
//                  _rulerPickerController.value = showValue;
//                },
//              ),
//            )
